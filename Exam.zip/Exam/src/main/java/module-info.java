module com.trios.exam {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.dlsc.formsfx;
    requires java.sql;

    opens com.trios.exam to javafx.fxml;
    exports com.trios.exam;
}