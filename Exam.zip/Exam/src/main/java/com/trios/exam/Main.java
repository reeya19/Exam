package com.trios.exam;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.property.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.sql.*;

public class Main extends Application {
    private TableView<Film> tableView;
    private Connection connection;
    private TextField titleField, releaseYearField, languageIdField;
    private TextArea descriptionArea;
    private Label messageLabel;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("🎬 Film Management System 🎬");

        // TableView setup
        tableView = new TableView<>();
        TableColumn<Film, Integer> idColumn = new TableColumn<>("ID");
        idColumn.setCellValueFactory(cellData -> cellData.getValue().idProperty().asObject());
        TableColumn<Film, String> titleColumn = new TableColumn<>("Title");
        titleColumn.setCellValueFactory(cellData -> cellData.getValue().titleProperty());
        TableColumn<Film, Integer> yearColumn = new TableColumn<>("Release Year");
        yearColumn.setCellValueFactory(cellData -> cellData.getValue().releaseYearProperty().asObject());
        TableColumn<Film, String> descriptionColumn = new TableColumn<>("Description");
        descriptionColumn.setCellValueFactory(cellData -> cellData.getValue().descriptionProperty());
        TableColumn<Film, Integer> languageIdColumn = new TableColumn<>("Language ID");
        languageIdColumn.setCellValueFactory(cellData -> cellData.getValue().languageIdProperty().asObject());

        tableView.getColumns().addAll(idColumn, titleColumn, yearColumn, descriptionColumn, languageIdColumn);
        tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        // Input Fields
        titleField = new TextField();
        releaseYearField = new TextField();
        descriptionArea = new TextArea();
        descriptionArea.setPrefRowCount(3);
        languageIdField = new TextField();

        // Buttons
        Button loadButton = new Button("🔄 Load Data");
        loadButton.setOnAction(e -> loadDataFromDatabase());

        Button addButton = new Button("➕ Add Film");
        addButton.setOnAction(e -> addFilm());

        Button editButton = new Button("✏️ Edit Film");
        editButton.setOnAction(e -> editFilm());

        Button clearButton = new Button("🗑️ Clear Fields");
        clearButton.setOnAction(e -> clearFields());

        messageLabel = new Label("Status: Ready");
        messageLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: blue;");

        // Table row selection to fill input fields
        tableView.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                titleField.setText(newSelection.getTitle());
                releaseYearField.setText(String.valueOf(newSelection.getReleaseYear()));
                descriptionArea.setText(newSelection.getDescription());
                languageIdField.setText(String.valueOf(newSelection.getLanguageId()));
            }
        });

        // Layout
        GridPane inputGrid = new GridPane();
        inputGrid.setHgap(10);
        inputGrid.setVgap(10);
        inputGrid.setPadding(new Insets(10));
        inputGrid.addRow(0, new Label("Title:"), titleField);
        inputGrid.addRow(1, new Label("Release Year:"), releaseYearField);
        inputGrid.addRow(2, new Label("Description:"), descriptionArea);
        inputGrid.addRow(3, new Label("Language ID:"), languageIdField);

        HBox buttonBox = new HBox(10, loadButton, addButton, editButton, clearButton);
        buttonBox.setPadding(new Insets(10));

        VBox layout = new VBox(10, tableView, inputGrid, buttonBox, messageLabel);
        layout.setPadding(new Insets(15));

        // Scene setup
        Scene scene = new Scene(layout, 700, 500);
        primaryStage.setScene(scene);
        primaryStage.show();

        // Database connection
        establishDatabaseConnection();
    }

    private void establishDatabaseConnection() {
        String url = "jdbc:mysql://localhost:3307/sakila";
        String username = "root";
        String password = "root"; // Change to your actual password

        try {
            connection = DriverManager.getConnection(url, username, password);
            showMessage("✅ Database connected successfully.", "green");
        } catch (SQLException e) {
            showError("❌ Database connection failed: " + e.getMessage());
        }
    }

    private void loadDataFromDatabase() {
        ObservableList<Film> films = FXCollections.observableArrayList();
        try {
            String query = "SELECT * FROM film";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                films.add(new Film(
                        resultSet.getInt("film_id"),
                        resultSet.getString("title"),
                        resultSet.getInt("release_year"),
                        resultSet.getString("description"),
                        resultSet.getInt("language_id")
                ));
            }
            tableView.setItems(films);
            showMessage("📥 Data loaded successfully.", "blue");
        } catch (SQLException e) {
            showError("❌ Error loading data: " + e.getMessage());
        }
    }

    private void addFilm() {
        try {
            String title = titleField.getText();
            int releaseYear = Integer.parseInt(releaseYearField.getText());
            String description = descriptionArea.getText();
            int languageId = Integer.parseInt(languageIdField.getText());

            String query = "INSERT INTO film (title, release_year, description, language_id) VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt = connection.prepareStatement(query);
            pstmt.setString(1, title);
            pstmt.setInt(2, releaseYear);
            pstmt.setString(3, description);
            pstmt.setInt(4, languageId);

            if (pstmt.executeUpdate() > 0) {
                showMessage("✅ Film added successfully!", "green");
                loadDataFromDatabase();
                clearFields();
            }
        } catch (SQLException | NumberFormatException e) {
            showError("❌ Error adding film: " + e.getMessage());
        }
    }

    private void editFilm() {
        Film selectedFilm = tableView.getSelectionModel().getSelectedItem();
        if (selectedFilm != null) {
            try {
                String title = titleField.getText();
                int releaseYear = Integer.parseInt(releaseYearField.getText());
                String description = descriptionArea.getText();
                int languageId = Integer.parseInt(languageIdField.getText());

                String query = "UPDATE film SET title = ?, release_year = ?, description = ?, language_id = ? WHERE film_id = ?";
                PreparedStatement pstmt = connection.prepareStatement(query);
                pstmt.setString(1, title);
                pstmt.setInt(2, releaseYear);
                pstmt.setString(3, description);
                pstmt.setInt(4, languageId);
                pstmt.setInt(5, selectedFilm.getId());

                if (pstmt.executeUpdate() > 0) {
                    showMessage("✅ Film updated successfully!", "green");
                    loadDataFromDatabase();
                    clearFields();
                }
            } catch (SQLException | NumberFormatException e) {
                showError("❌ Error updating film: " + e.getMessage());
            }
        } else {
            showError("⚠️ Please select a film to edit.");
        }
    }

    private void showMessage(String message, String color) {
        messageLabel.setText(message);
        messageLabel.setStyle("-fx-text-fill: " + color + ";");
        clearMessageAfterDelay();
    }

    private void showError(String message) {
        showMessage(message, "red");
    }

    private void clearFields() {
        titleField.clear();
        releaseYearField.clear();
        descriptionArea.clear();
        languageIdField.clear();
    }

    private void clearMessageAfterDelay() {
        new Thread(() -> {
            try {
                Thread.sleep(5000);
                Platform.runLater(() -> messageLabel.setText("Status: Ready"));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();
    }
}

// Film Class (Inside the same file)
class Film {
    private final IntegerProperty id;
    private final StringProperty title;
    private final IntegerProperty releaseYear;
    private final StringProperty description;
    private final IntegerProperty languageId;

    public Film(int id, String title, int releaseYear, String description, int languageId) {
        this.id = new SimpleIntegerProperty(id);
        this.title = new SimpleStringProperty(title);
        this.releaseYear = new SimpleIntegerProperty(releaseYear);
        this.description = new SimpleStringProperty(description);
        this.languageId = new SimpleIntegerProperty(languageId);
    }

    public int getId() { return id.get(); }
    public String getTitle() { return title.get(); }
    public int getReleaseYear() { return releaseYear.get(); }
    public String getDescription() { return description.get(); }
    public int getLanguageId() { return languageId.get(); }

    public IntegerProperty idProperty() { return id; }
    public StringProperty titleProperty() { return title; }
    public IntegerProperty releaseYearProperty() { return releaseYear; }
    public StringProperty descriptionProperty() { return description; }
    public IntegerProperty languageIdProperty() { return languageId; }
}
