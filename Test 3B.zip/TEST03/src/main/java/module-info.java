module com.example.test03 {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.dlsc.formsfx;
    requires java.sql;

    opens com.example.test03 to javafx.fxml;
    exports com.example.test03;
    exports com.example.test03.view;
    opens com.example.test03.view to javafx.fxml;
    exports com.example.test03.model;
    opens com.example.test03.model to javafx.fxml;
    exports com.example.test03.dao;
    opens com.example.test03.dao to javafx.fxml;
}