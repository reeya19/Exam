package com.example.test03.view;

import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import com.example.test03.model.PizzaOrder;
import com.example.test03.dao.PizzaOrderDAO;

public class PizzaOrderPage extends GridPane {

    private TextField customerNameField, mobileNumberField;
    private CheckBox xlSize, lSize, mSize, sSize;
    private Spinner<Integer> toppingCountSpinner;
    private Button addButton, updateButton, deleteButton, clearButton;
    private TableView<PizzaOrder> ordersTable;

    public PizzaOrderPage() {
        setPadding(new Insets(10));
        setVgap(10);
        setHgap(10);

        // UI Components
        customerNameField = new TextField();
        mobileNumberField = new TextField();
        xlSize = new CheckBox("XL");
        lSize = new CheckBox("L");
        mSize = new CheckBox("M");
        sSize = new CheckBox("S");
        toppingCountSpinner = new Spinner<>(0, 10, 0); // Toppings count from 0 to 10
        addButton = new Button("Add Order");
        updateButton = new Button("Update Order");
        deleteButton = new Button("Delete Order");
        clearButton = new Button("Clear Form");

        ordersTable = new TableView<>();
        setupTable();

        // Layout setup
        add(new Label("Customer Name:"), 0, 0);
        add(customerNameField, 1, 0);
        add(new Label("Mobile Number:"), 0, 1);
        add(mobileNumberField, 1, 1);
        add(new Label("Pizza Size:"), 0, 2);
        add(xlSize, 1, 2);
        add(lSize, 2, 2);
        add(mSize, 3, 2);
        add(sSize, 4, 2);
        add(new Label("Number of Toppings:"), 0, 3);
        add(toppingCountSpinner, 1, 3);
        add(addButton, 0, 4);
        add(updateButton, 1, 4);
        add(deleteButton, 2, 4);
        add(clearButton, 3, 4);
        add(ordersTable, 0, 5, 5, 1);

        // Event Handlers
        addButton.setOnAction(event -> addOrder());
        updateButton.setOnAction(event -> updateOrder());
        deleteButton.setOnAction(event -> deleteOrder());
        clearButton.setOnAction(event -> clearForm());
    }

    private void setupTable() {
        // Set up columns for the TableView
        TableColumn<PizzaOrder, String> customerNameColumn = new TableColumn<>("Customer Name");
        customerNameColumn.setCellValueFactory(cellData -> cellData.getValue().customerNameProperty());

        TableColumn<PizzaOrder, String> mobileNumberColumn = new TableColumn<>("Mobile Number");
        mobileNumberColumn.setCellValueFactory(cellData -> cellData.getValue().mobileNumberProperty());

        TableColumn<PizzaOrder, String> pizzaSizeColumn = new TableColumn<>("Pizza Size");
        pizzaSizeColumn.setCellValueFactory(cellData -> cellData.getValue().pizzaSizeProperty());

        TableColumn<PizzaOrder, Integer> toppingsColumn = new TableColumn<>("Toppings");
        toppingsColumn.setCellValueFactory(cellData -> cellData.getValue().numToppingsProperty().asObject());

        TableColumn<PizzaOrder, Double> totalBillColumn = new TableColumn<>("Total Bill");
        totalBillColumn.setCellValueFactory(cellData -> cellData.getValue().totalBillProperty().asObject());

        ordersTable.getColumns().addAll(customerNameColumn, mobileNumberColumn, pizzaSizeColumn, toppingsColumn, totalBillColumn);
    }

    private void addOrder() {
        String customerName = customerNameField.getText();
        String mobileNumber = mobileNumberField.getText();
        String pizzaSize = getSelectedPizzaSize();
        int numToppings = toppingCountSpinner.getValue();
        double totalBill = calculateTotalBill(pizzaSize, numToppings);

        // Create a PizzaOrder object
        PizzaOrder pizzaOrder = new PizzaOrder(customerName, mobileNumber, pizzaSize, numToppings, totalBill);

        // Use PizzaOrderDAO to save the order in the database
        PizzaOrderDAO.addOrder(pizzaOrder);

        // Update the TableView with the new order
        ordersTable.getItems().add(pizzaOrder);

        // Clear the form fields
        clearForm();
    }

    private String getSelectedPizzaSize() {
        if (xlSize.isSelected()) return "XL";
        if (lSize.isSelected()) return "L";
        if (mSize.isSelected()) return "M";
        return "S";
    }

    private double calculateTotalBill(String pizzaSize, int numToppings) {
        double sizeCost = 0;
        switch (pizzaSize) {
            case "XL": sizeCost = 15.00; break;
            case "L": sizeCost = 12.00; break;
            case "M": sizeCost = 10.00; break;
            case "S": sizeCost = 8.00; break;
        }
        double toppingCost = numToppings * 1.50;
        double total = sizeCost + toppingCost;
        return total + (total * 0.15); // Add 15% HST
    }

    private void updateOrder() {
        PizzaOrder selectedOrder = ordersTable.getSelectionModel().getSelectedItem();
        if (selectedOrder != null) {
            selectedOrder.setPizzaSize(getSelectedPizzaSize());
            selectedOrder.setNumToppings(toppingCountSpinner.getValue());
            selectedOrder.setTotalBill(calculateTotalBill(selectedOrder.getPizzaSize(), selectedOrder.getNumToppings()));
            PizzaOrderDAO.updateOrder(selectedOrder);
            ordersTable.refresh();
        }
    }

    private void deleteOrder() {
        PizzaOrder selectedOrder = ordersTable.getSelectionModel().getSelectedItem();
        if (selectedOrder != null) {
            PizzaOrderDAO.deleteOrder(selectedOrder);
            ordersTable.getItems().remove(selectedOrder);
        }
    }

    private void clearForm() {
        customerNameField.clear();
        mobileNumberField.clear();
        xlSize.setSelected(false);
        lSize.setSelected(false);
        mSize.setSelected(false);
        sSize.setSelected(false);
        toppingCountSpinner.getValueFactory().setValue(0);
    }
}
