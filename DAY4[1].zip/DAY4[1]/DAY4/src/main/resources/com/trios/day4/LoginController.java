package com.trios.day4;

public class LoginController {
}
