module com.trios.day4 {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.dlsc.formsfx;

    opens com.trios.day4 to javafx.fxml;
    exports com.trios.day4;
}