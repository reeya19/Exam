package com.trios.day4 ;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class LoginController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Button loginButton;

    @FXML
    private Label messageLabel;

    private int failedAttempts = 0;
    private final int MAX_ATTEMPTS = 5;

    // Static credentials
    private static final String STATIC_USERNAME = "Reeya";
    private static final String STATIC_PASSWORD = "2004";

    @FXML
    public void handleLogin() {
        String username = usernameField.getText();
        String password = passwordField.getText();

        if (failedAttempts >= MAX_ATTEMPTS) {
            messageLabel.setText("Sorry, Your Account is Locked!!!");
            return;
        }

        if (username.isEmpty() || password.isEmpty()) {
            messageLabel.setText("Please Provide Username or Password");
            return;
        }

        if (username.equals(STATIC_USERNAME) && password.equals(STATIC_PASSWORD)) {
            messageLabel.setText("Success!!!");
            failedAttempts = 0;  // Reset failed attempts on successful login
        } else {
            failedAttempts++;
            if (failedAttempts >= MAX_ATTEMPTS) {
                messageLabel.setText("Sorry, Your Account is Locked!!!");
            } else {
                messageLabel.setText("Sorry, Invalid Username or Password");
            }
        }
    }
}
