package com.trios.day4;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.time.LocalDate;

public class LoginApp extends Application {
    private int failedAttempts = 0;
    private static final int MAX_ATTEMPTS = 5;
    private static final String STATIC_USERNAME = "Reeya";
    private static final String STATIC_PASSWORD = "2004";

    @Override
    public void start(Stage primaryStage) {
        // Create UI components
        Label titleLabel = new Label("Login Page");
        Label nameLabel = new Label("Your Name: [Your Name]");
        Label dateLabel = new Label("Date: " + LocalDate.now());
        Label idLabel = new Label("Student ID: [Your Student ID]");

        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");

        Button loginButton = new Button("Login");
        Label messageLabel = new Label();
        Label attemptLabel = new Label("Failed Attempts: 0 / " + MAX_ATTEMPTS);

        // Login button action
        loginButton.setOnAction(e -> {
            String username = usernameField.getText();
            String password = passwordField.getText();

            if (failedAttempts >= MAX_ATTEMPTS) {
                messageLabel.setText("Sorry, Your Account is Locked!!!");
                return;
            }

            if (username.isEmpty() || password.isEmpty()) {
                messageLabel.setText("Please Provide Username or Password");
                return;
            }

            if (username.equals(STATIC_USERNAME) && password.equals(STATIC_PASSWORD)) {
                messageLabel.setText("Success!!!");
                failedAttempts = 0; // Reset counter on successful login
                attemptLabel.setText("Failed Attempts: 0 / " + MAX_ATTEMPTS);
            } else {
                failedAttempts++;
                if (failedAttempts >= MAX_ATTEMPTS) {
                    messageLabel.setText("Sorry, Your Account is Locked!!!");
                } else {
                    messageLabel.setText("Sorry, Invalid Username or Password");
                }
                attemptLabel.setText("Failed Attempts: " + failedAttempts + " / " + MAX_ATTEMPTS);
            }
        });

        // Layout setup
        VBox layout = new VBox(10);
        layout.getChildren().addAll(titleLabel, nameLabel, dateLabel, idLabel, usernameField, passwordField, loginButton, messageLabel, attemptLabel);

        // Scene setup
        Scene scene = new Scene(layout, 400, 400);
        primaryStage.setTitle("JavaFX Login Application");
        primaryStage.setScene(scene);

        // Show the stage
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
